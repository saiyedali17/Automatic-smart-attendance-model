import pandas as pd
from glob import glob
import os
import tkinter
import csv
import tkinter as tk
from tkinter import *

# --- MODERN LIGHT THEME COLOR PALETTE ---
PRIMARY_LIGHT = "#FFFFFF"     # Main window background (White)
SECONDARY_BG = "#F0F0F0"     # Light gray for a subtle contrast
HEADER_LIGHT = "#E0E0E0"     # Slightly darker gray for header bar
ACCENT_MAROON = "#800000"    # Maroon accent color for buttons, outlines
ACCENT_GREEN = "#2ECC71"     # Success/positive feedback
ACCENT_RED = "#E74C3C"       # Danger/critical action
TEXT_DARK = "#333333"        # Dark text for contrast on light backgrounds
TEXT_LIGHT = "#FFFFFF"       # White text for contrast on dark buttons

def subjectchoose(text_to_speech):
    def calculate_attendance():
        Subject = tx.get()
        if Subject=="":
            t='Please enter the subject name.'
            text_to_speech(t)
    
        filenames = glob(
            f"Attendance\\{Subject}\\{Subject}*.csv"
        )
        df = [pd.read_csv(f) for f in filenames]
        newdf = df[0]
        for i in range(1, len(df)):
            newdf = newdf.merge(df[i], how="outer")
        newdf.fillna(0, inplace=True)
        newdf["Attendance"] = 0
        for i in range(len(newdf)):
            newdf["Attendance"].iloc[i] = str(int(round(newdf.iloc[i, 2:-1].mean() * 100)))+'%'
            #newdf.sort_values(by=['Enrollment'],inplace=True)
        newdf.to_csv(f"Attendance\\{Subject}\\attendance.csv", index=False)

        root = tkinter.Tk()
        root.title("Attendance of "+Subject)
        root.configure( bg=PRIMARY_LIGHT)
        cs = f"Attendance\\{Subject}\\attendance.csv"
        with open(cs) as file:
            reader = csv.reader(file)
            r = 0

            for col in reader:
                c = 0
                for row in col:

                    label = tkinter.Label(
                        root,
                        width=10,
                        height=1,
                        bg=HEADER_LIGHT,
                        fg=TEXT_DARK,
                        font=("times", 15, " bold "),
                        text=row,
                        relief=tkinter.RIDGE,
                    )
                    label.grid(row=r, column=c)
                    c += 1
                r += 1
        root.mainloop()
        print(newdf)

    subject = Tk()
    # windo.iconbitmap("AMS.ico")
    subject.title("View Attendance")
    subject.geometry("580x320")
    subject.resizable(0, 0)
    subject.configure( bg=PRIMARY_LIGHT)
    # subject_logo = Image.open("UI_Image/0004.png")
    # subject_logo = subject_logo.resize((50, 47), Image.ANTIALIAS)
    # subject_logo1 = ImageTk.PhotoImage(subject_logo)
    titl = tk.Label(subject,  bg=PRIMARY_LIGHT, relief=RIDGE, bd=10, font=("arial", 30))
    titl.pack(fill=X)
    # l1 = tk.Label(subject, image=subject_logo1, bg="black",)
    # l1.place(x=100, y=10)
    titl = tk.Label(
        subject,
        text="Attendance Viewer",
        bg=HEADER_LIGHT,
        fg=TEXT_DARK,
        font=("arial", 25),
    )
    titl.place(x=150, y=12)

    def Attf():
        sub = tx.get()
        if sub == "":
            t="Please enter the subject name!!!"
            text_to_speech(t)
        else:
            os.startfile(
            f"Attendance\\{sub}"
            )


    attf = tk.Button(
        subject,
        text="Check Attendance",
        command=Attf,
        bd=7,
        font=("times new roman", 15),
       bg=ACCENT_MAROON,
        fg=TEXT_LIGHT,
        height=2,
        width=15,
        relief=RIDGE,
    )
    attf.place(x=360, y=170)

    sub = tk.Label(
        subject,
        text="Enter Subject",
        width=10,
        height=2,
        bg=PRIMARY_LIGHT,
        fg=TEXT_DARK,
        bd=5,
        relief=RIDGE,
        font=("times new roman", 15),
    )
    sub.place(x=50, y=100)

    tx = tk.Entry(
        subject,
        width=17,
        bd=5,
        bg=SECONDARY_BG,
        fg=TEXT_DARK,
        relief=RIDGE,
        font=("times", 30, "bold"),
    )
    tx.place(x=190, y=100)

    fill_a = tk.Button(
        subject,
        text="View Attendance",
        command=calculate_attendance,
        bd=7,
        font=("times new roman", 15),
        bg=ACCENT_MAROON,
        fg=TEXT_LIGHT,
        height=2,
        width=12,
        relief=RIDGE,
    )
    fill_a.place(x=195, y=170)
    subject.mainloop()
