import tkinter as tk
from tkinter import *
import os, cv2
import shutil
import csv
import numpy as np
from PIL import ImageTk, Image
import pandas as pd
import datetime
import time
import tkinter.font as font
import pyttsx3

# project module
import show_attendance
import takeImage
import trainImage
import automaticAttedance

# engine = pyttsx3.init()
# engine.say("Welcome!")
# engine.say("Please browse through your options..")
# engine.runAndWait()


def text_to_speech(user_text):
    engine = pyttsx3.init()
    engine.say(user_text)
    engine.runAndWait()


haarcasecade_path = "haarcascade_frontalface_default.xml"
trainimagelabel_path = (
    "./TrainingImageLabel/Trainner.yml"
)
trainimage_path = "/TrainingImage"
if not os.path.exists(trainimage_path):
    os.makedirs(trainimage_path)

studentdetail_path = (
    "./StudentDetails/studentdetails.csv"
)
attendance_path = "Attendance"

window = Tk()
window.title("Face Recognizer")
window.geometry("1280x720")
dialog_title = "QUIT"
dialog_text = "Are you sure want to close?"

PRIMARY_LIGHT = "#FFFFFF"     # Main window background (White)
SECONDARY_BG = "#F0F0F0"     # Light gray for a subtle contrast
HEADER_LIGHT = "#E0E0E0"     # Slightly darker gray for header bar
ACCENT_MAROON = "#800000"    # Maroon accent color for buttons, outlines
ACCENT_GREEN = "#2ECC71"     # Success/positive feedback
ACCENT_RED = "#E74C3C"       # Danger/critical action (if any)
TEXT_DARK = "#333333"        # Dark text for contrast on light backgrounds
TEXT_LIGHT = "#FFFFFF"       # White text for contrast on dark buttons


window.configure(background=PRIMARY_LIGHT)

#window.configure(background="#1c1c1c")  # Dark theme


# to destroy screen
def del_sc1():
    sc1.destroy()


# error message for name and no
def err_screen():
    global sc1
    sc1 = tk.Tk()
    sc1.geometry("400x110")
    sc1.iconbitmap("AMS.ico")
    sc1.title("Warning!!")
    sc1.configure(background="#1c1c1c")
    sc1.resizable(0, 0)
    tk.Label(
        sc1,
        text="Enrollment & Name required!!!",
        fg=ACCENT_RED,
        bg=SECONDARY_BG,
        font=("Segoe UI", 16, "bold"),
    ).pack(pady=10)
    tk.Button(
        sc1,
        text="OK",
        command=del_sc1,
        fg=TEXT_LIGHT,
        bg=ACCENT_MAROON, 
        width=9,
        height=1,
        activebackground="#500000", 
        font=("Segoe UI", 14, "bold"),
        relief=FLAT
    ).place(x=110, y=60)

def testVal(inStr, acttyp):
    if acttyp == "1":  # insert
        if not inStr.isdigit():
            return False
    return True


logo = Image.open("UI_Image/0001.png")
logo = logo.resize((50, 47), Image.LANCZOS)
logo1 = ImageTk.PhotoImage(logo)
titl = tk.Label(window, bg=ACCENT_MAROON, relief=RIDGE, bd=10, font=("Verdana", 30, "bold"))
titl.pack(fill=X)
l1 = tk.Label(window, image=logo1,)
l1.place(x=480, y=10)


titl = tk.Label(
    window, text="Smart Attendance Portal", bg=ACCENT_MAROON, fg=TEXT_LIGHT, font=("Verdana", 27, "bold"),
)
titl.place(x=560, y=12)

a = tk.Label(
    window,
    text="Welcome ",
    bg=PRIMARY_LIGHT,
    fg=ACCENT_MAROON,
    font=("Segoe UI", 32, "bold"),
)
a.pack(pady=30)


ri = Image.open("UI_Image/register.png")
ri = ri.resize((200, 200))
r = ImageTk.PhotoImage(ri)
label1 = Label(window, image=r)
label1.image = r
label1.place(x=200, y=300)

ai = Image.open("UI_Image/attendance.png")
ai = ai.resize((200, 200))
a = ImageTk.PhotoImage(ai)
label2 = Label(window, image=a)
label2.image = a
label2.place(x=1110, y=300)

vi = Image.open("UI_Image/verifyy.png")
vi = vi.resize((200, 200))
v = ImageTk.PhotoImage(vi)
label3 = Label(window, image=v)
label3.image = v
label3.place(x=660, y=300)


def TakeImageUI():
    ImageUI = Tk()
    ImageUI.title("Register New Student")
    ImageUI.geometry("780x480")
    ImageUI.configure(background=PRIMARY_LIGHT)  
    ImageUI.resizable(0, 0)
    titl = tk.Label(ImageUI, bg=HEADER_LIGHT, fg=TEXT_DARK, font=("Segoe UI", 24, "bold"))
    titl.pack(fill=X)
    # image and title
    titl = tk.Label(
        ImageUI, text="New Face Registration", bg=HEADER_LIGHT, fg=TEXT_DARK, font=("Segoe UI", 24, "bold"),
    )
    titl.place(x=270, y=12)

    # heading
    a = tk.Label(
        ImageUI,
        text="Enter New Student Data",
        bg=PRIMARY_LIGHT,
        fg=TEXT_DARK,
        font=("Segoe UI", 20, "bold"),
    )
    a.place(x=280, y=75)

    # ER no
    lbl1 = tk.Label(
        ImageUI,
        text="Roll No.",
        width=10,
        height=2,
        bg=PRIMARY_LIGHT,
        fg=TEXT_DARK,
        bd=5,
        relief=RIDGE,
        font=("Verdana", 14),
    )
    lbl1.place(x=120, y=130)
    txt1 = tk.Entry(
        ImageUI,
        width=24,
        bd=5,
        validate="key",
        bg=SECONDARY_BG,
        fg=TEXT_DARK, 
        relief=RIDGE,
        font=("Verdana", 18, "bold"),
    )
    txt1.place(x=250, y=130)
    txt1["validatecommand"] = (txt1.register(testVal), "%P", "%d")

    # name
    lbl2 = tk.Label(
        ImageUI,
        text="Name",
        width=10,
        height=2,
        bg=PRIMARY_LIGHT,
        fg=TEXT_DARK,
        bd=5,
        relief=RIDGE,
        font=("Verdana", 14),
    )
    lbl2.place(x=120, y=200)
    txt2 = tk.Entry(
        ImageUI,
        width=24,
        bd=5,
        bg=SECONDARY_BG,
        fg=TEXT_DARK,
        relief=RIDGE,
        font=("Verdana", 18, "bold"),
    )
    txt2.place(x=250, y=200)

    lbl3 = tk.Label(
        ImageUI,
        text="Result",
        width=10,
        height=2,
        bg=PRIMARY_LIGHT,
        fg=TEXT_DARK,
        bd=5,
        relief=RIDGE,
        font=("Verdana", 14),
    )
    lbl3.place(x=120, y=270)

    message = tk.Label(
        ImageUI,
        text="",
        width=32,
        height=2,
        bd=5,
        bg=SECONDARY_BG,
        fg=ACCENT_GREEN,
        relief=RIDGE,
        font=("Verdana", 14, "bold"),
    )
    message.place(x=250, y=270)

    def take_image():
        l1 = txt1.get()
        l2 = txt2.get()
        takeImage.TakeImage(
            l1,
            l2,
            haarcasecade_path,
            trainimage_path,
            message,
            err_screen,
            text_to_speech,
        )
        txt1.delete(0, "end")
        txt2.delete(0, "end")

    # take Image button
    # image
    takeImg = tk.Button(
        ImageUI,
        text="Take Image",
        command=take_image,
        bd=10,
        font=("Verdana", 18, "bold"),
        bg=ACCENT_MAROON, 
        fg=TEXT_LIGHT,
        height=2,
        width=12,
        relief=RIDGE,
    )
    takeImg.place(x=130, y=350)

    def train_image():
        trainImage.TrainImage(
            haarcasecade_path,
            trainimage_path,
            trainimagelabel_path,
            message,
            text_to_speech,
        )

    # train Image function call
    trainImg = tk.Button(
        ImageUI,
        text="Train Image",
        command=train_image,
        bd=10,
        font=("Verdana", 18, "bold"),
        bg=ACCENT_MAROON, 
        fg=TEXT_LIGHT,
        height=2,
        width=12,
        relief=RIDGE,
    )
    trainImg.place(x=360, y=350)


r = tk.Button(
    window,
    text="Register student",
    command=TakeImageUI,
    bd=10,
    font=("Verdana", 16),
    bg=ACCENT_MAROON,
    fg=TEXT_LIGHT,
    height=2,
    width=17,
)
r.place(x=180, y=520)


def automatic_attedance():
    automaticAttedance.subjectChoose(text_to_speech)


r = tk.Button(
    window,
    text="Take Attendance",
    command=automatic_attedance,
    bd=10,
    font=("Verdana", 16),
    bg=ACCENT_MAROON,
    fg=TEXT_LIGHT,
    height=2,
    width=17,
)
r.place(x=640, y=520)


def view_attendance():
    show_attendance.subjectchoose(text_to_speech)


r = tk.Button(
    window,
    text="View Attendance",
    command=view_attendance,
    bd=10,
    font=("Verdana", 16),
    bg=ACCENT_MAROON,
    fg=TEXT_LIGHT,
    height=2,
    width=17,
)

r.place(x=1095, y=520)
r = tk.Button(
    window,
    text="EXIT",
    bd=10,
    command=quit,
    font=("Verdana", 16),
    bg=ACCENT_MAROON,
    fg=TEXT_LIGHT,
    height=2,
    width=17,
)
r.place(x=650, y=660)


window.mainloop()