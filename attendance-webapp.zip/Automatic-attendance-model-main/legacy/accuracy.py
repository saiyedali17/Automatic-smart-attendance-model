import os
import cv2
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report
import itertools

# ============================
# CONFIG
# ============================
TEST_DIR = "TestImages"
MODEL_PATH = "TrainingImageLabel/Trainner.yml"
HAAR = "haarcascade_frontalface_default.xml"

# ============================
# LOAD MODEL
# ============================
if not os.path.exists(MODEL_PATH):
    raise SystemExit("Model not found: " + MODEL_PATH)

recognizer = cv2.face.LBPHFaceRecognizer_create()
recognizer.read(MODEL_PATH)

haar = cv2.CascadeClassifier(HAAR)

y_true = []
y_pred = []

print("\n=== STARTING ACCURACY & CONFUSION MATRIX EVALUATION ===\n")

# ============================
# READ TEST IMAGES
# ============================
for folder in sorted(os.listdir(TEST_DIR)):
    folder_path = os.path.join(TEST_DIR, folder)
    if not os.path.isdir(folder_path):
        continue

    try:
        true_id = int(folder.split("_")[0])   # 1_Aazin → 1
    except:
        print("Skipping:", folder)
        continue

    for img_file in os.listdir(folder_path):
        img_path = os.path.join(folder_path, img_file)
        if not img_path.lower().endswith((".jpg", ".jpeg", ".png")):
            continue

        img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
        if img is None:
            continue

        faces = haar.detectMultiScale(img, 1.2, 5)
        if len(faces) > 0:
            x, y, w, h = faces[0]
            roi = img[y:y+h, x:x+w]
        else:
            roi = img

        roi = cv2.resize(roi, (200, 200))
        roi = cv2.equalizeHist(roi)

        pred_id, conf = recognizer.predict(roi)

        print(f"TRUE={true_id}, PRED={pred_id}, CONF={conf:.2f}")

        y_true.append(true_id)
        y_pred.append(pred_id)

# ============================
# METRICS
# ============================
print("\n=== METRICS ===")
accuracy = accuracy_score(y_true, y_pred)
print(f"Accuracy: {accuracy * 100:.2f}%\n")

cm = confusion_matrix(y_true, y_pred)
print("Confusion Matrix:\n", cm)

print("\nClassification Report:")
print(classification_report(y_true, y_pred))

# ============================
# CONFUSION MATRIX PLOT
# ============================
def plot_cm(cm, labels):
    plt.figure(figsize=(7, 7))
    plt.imshow(cm, interpolation='nearest', cmap=plt.cm.Blues)
    plt.title("Confusion Matrix", fontsize=16)
    plt.colorbar()

    ticks = np.arange(len(labels))
    plt.xticks(ticks, labels, rotation=45)
    plt.yticks(ticks, labels)

    threshold = cm.max() / 2.

    for i, j in itertools.product(range(cm.shape[0]), range(cm.shape[1])):
        color = "white" if cm[i, j] > threshold else "black"
        plt.text(j, i, format(cm[i, j], 'd'),
                 horizontalalignment="center", color=color, fontsize=14)

    plt.ylabel("True Label", fontsize=14)
    plt.xlabel("Predicted Label", fontsize=14)
    plt.tight_layout()
    plt.show()

labels = sorted(list(set(y_true)))
print("\nShowing Confusion Matrix Plot...")
plot_cm(cm, labels)
